//97 ES1 ..... 2015 => ES6 ES7 ES8 ES9. ... . 
//var , let , const
//template literals
//default parameters
function welcome(userName = 'system user', age = 25, salary = 3000) {
    console.log(`welcome ${userName} your age is ${age} you salary is ${salary}`);
}
welcome('ahmed');
